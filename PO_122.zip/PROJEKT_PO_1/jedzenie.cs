﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJEKT_PO_1
{
    public class jedzenie

    {
        public string kod_produktu { get; set; }
        public string nazwa_produktu { get; set; }
        public string ilosc_glukozy { get; set; }
    }
}
