﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJEKT_PO_1
{
    class zmienne
    {
        public static string[] dataWords;
        public static int KodKresk;
        public static string AdresPliku;
    }
}
